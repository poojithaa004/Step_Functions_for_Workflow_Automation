#ShippingProcess

import json

def lambda_handler(event, context):
    try:
        # Check if 'body' is present and parse it
        if "body" in event:
            body = json.loads(event["body"])  # Convert string to dictionary
        else:
            body = event  # Fallback in case it's already a dictionary

        order_id = body.get("order_id")  # Safely extract order_id

        if not order_id:
            raise KeyError("order_id is missing")

        # Continue with shipping process logic...
        return {
            "statusCode": 200,
            "body": json.dumps({"order_id": order_id, "status": "Shipped"})
        }

    except Exception as e:
        return {
            "statusCode": 400,
            "error": str(e)
        }