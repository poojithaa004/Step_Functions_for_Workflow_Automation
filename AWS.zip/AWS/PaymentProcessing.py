#PaymentProcessing

import json
import boto3
import random

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Orders')

def lambda_handler(event, context):
    body = json.loads(event["body"])  # Fix to access order_id correctly
    order_id = body["order_id"]

    payment_success = random.choice([True, False])

    if payment_success:
        status = "Payment Successful"
    else:
        status = "Payment Failed"

    table.update_item(
        Key={'order_id': order_id},
        UpdateExpression="SET #s = :s",  # Use alias for 'status'
        ExpressionAttributeNames={'#s': 'status'},  # Define alias
        ExpressionAttributeValues={':s': status}
    )

    return {
        "statusCode": 200 if payment_success else 400,
        "body": json.dumps({"order_id": order_id, "status": status})
    }