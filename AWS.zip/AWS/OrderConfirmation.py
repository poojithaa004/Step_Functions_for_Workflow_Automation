#OrderConfirmation

import json
import boto3

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Orders')

def lambda_handler(event, context):
    body = json.loads(event["body"])  # Extract the 'order_id' from body
    order_id = body["order_id"]

    # 'status' is a reserved keyword — use ExpressionAttributeNames to handle this
    table.update_item(
        Key={'order_id': order_id},
        UpdateExpression="SET #s = :s",
        ExpressionAttributeNames={'#s': 'status'},
        ExpressionAttributeValues={':s': "Order Confirmed"}
    )

    return {
        "statusCode": 200,
        "body": json.dumps({"order_id": order_id, "status": "Order Confirmed"})
    }