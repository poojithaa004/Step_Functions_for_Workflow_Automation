#orderPlacement

import json
import boto3
import uuid

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Orders')

def lambda_handler(event, context):
    order_id = str(uuid.uuid4())  # Generate a unique order ID
    order_data = {
        "order_id": order_id,
        "status": "Order Placed",
        "item": event.get("item", "Unknown Item"),
        "price": event.get("price", 0)
    }
    table.put_item(Item=order_data)  # Save to DynamoDB

    return {
        "statusCode": 200,
        "body": json.dumps(order_data)
    }